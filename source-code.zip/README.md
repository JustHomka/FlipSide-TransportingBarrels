# FlipSide-TransportingBarrels
FlipSide Minecraft server plugin for retaining items when you breake barrel

Links:

FlipSide RP Discord Server -> https://discord.gg/5DRCKTRhy3
                                                                  
FlipSide RP Dynamic Map -> [rp.flipside.net.ua](http://rp.flipside.net.ua/)
